"""AsyncExecutor — concurrent DAG execution via asyncio."""

from __future__ import annotations

import asyncio
from collections import deque
from pathlib import Path
from typing import TYPE_CHECKING, Callable

from smythe.budget import BudgetValidationError, Sentinel, SentinelAlert, validate_token_count
from smythe.executor_base import (
    DEFAULT_MAX_TOOL_ITERATIONS,
    ExecutorBase,
    NodeFinalizationError,
)
from smythe.graph import ExecutionGraph, FailurePolicy, Node, NodeStatus
from smythe.provider import Provider, ProviderResponseError
from smythe.registry import Registry
from smythe.tools import ToolRuntime
from smythe.tracer import Tracer
from smythe.verifier import VerificationRecoveryError
from smythe.workflow_store import WorkflowError

if TYPE_CHECKING:
    from smythe.supervisor import Supervisor
    from smythe.task import Task
    from smythe.verifier import Verifier


class AsyncExecutor(ExecutorBase):
    """Executes an assigned graph with maximum concurrency.

    Independent nodes (those whose dependencies are all completed)
    are launched as capacity becomes available.  Only the configured
    number of tasks is admitted to the event loop at once; a broadcast
    with thousands of nodes therefore does not create thousands of
    coroutines that merely wait behind a semaphore.

    Budget safety: estimated cost is reserved before each node is admitted,
    so concurrent admissions cannot collectively exceed the configured policy.
    Reservations are reconciled with reported cost or configured estimates on
    completion, or released on failure/cancellation.

    Concurrency safety: ``max_concurrency`` caps in-flight provider
    calls, so a wide broadcast doesn't fire every call
    at once and trip provider rate limits.  None means unlimited.
    """

    DEFAULT_ESTIMATED_TOKENS = 2000

    def __init__(
        self,
        provider: Provider,
        registry: Registry,
        tracer: Tracer,
        budget: Sentinel | None = None,
        estimated_tokens_per_node: int = DEFAULT_ESTIMATED_TOKENS,
        max_concurrency: int | None = None,
        on_node_update: Callable[[Node], None] | None = None,
        tool_runtime: ToolRuntime | None = None,
        max_tool_iterations: int = DEFAULT_MAX_TOOL_ITERATIONS,
        artifact_dir: str | Path | None = "smythe_artifacts",
        retry_backoff_s: float = 0.0,
        supervisor: Supervisor | None = None,
        max_revisions: int = 0,
        task: Task | None = None,
        verifier: Verifier | None = None,
        revisions_used: int = 0,
        on_control_update: Callable[[], None] | None = None,
        provider_call_factory: Callable[[Node, str, int, int], Provider] | None = None,
        on_supervision_update: Callable[[Node, bool], None] | None = None,
    ) -> None:
        super().__init__(
            provider=provider, registry=registry, tracer=tracer, budget=budget,
            on_node_update=on_node_update, tool_runtime=tool_runtime,
            max_tool_iterations=max_tool_iterations, artifact_dir=artifact_dir,
            retry_backoff_s=retry_backoff_s, supervisor=supervisor,
            max_revisions=max_revisions, task=task, verifier=verifier,
            revisions_used=revisions_used,
            on_control_update=on_control_update,
            provider_call_factory=provider_call_factory,
            on_supervision_update=on_supervision_update,
        )
        self._estimated_tokens_per_node = validate_token_count(
            estimated_tokens_per_node, "estimated_tokens_per_node",
        )
        if max_concurrency is not None and max_concurrency < 1:
            raise ValueError(f"max_concurrency must be >= 1, got {max_concurrency}")
        self._max_concurrency = max_concurrency

    def _schedule_state(
        self, graph: ExecutionGraph, active: dict[asyncio.Task[None], Node],
    ) -> tuple[
        dict[str, Node], set[str], dict[str, list[Node]], dict[str, int],
        deque[Node], dict[str, int],
    ]:
        """Derive scheduling state from the graph's live node statuses.

        Also used to rebuild after a supervisor revision: node status is
        the authority, so recomputing from it is both simpler and safer
        than patching the derived structures node by node.  Nodes already
        in flight are excluded — they are running, not schedulable.
        """
        active_ids = {node.id for node in active.values()}
        pending = {
            node.id: node
            for node in graph.nodes
            if node.status == NodeStatus.PENDING and node.id not in active_ids
        }
        resolved = {
            node.id for node in graph.nodes
            if node.status in (NodeStatus.COMPLETED, NodeStatus.SKIPPED)
        }
        dependents: dict[str, list[Node]] = {node.id: [] for node in graph.nodes}
        unresolved: dict[str, int] = {}
        for node in graph.nodes:
            for dep_id in node.depends_on:
                dependents.setdefault(dep_id, []).append(node)
            if node.id in pending:
                unresolved[node.id] = sum(
                    dep_id not in resolved for dep_id in node.depends_on
                )
        ready = deque(
            node for node in graph.nodes
            if node.id in pending and unresolved[node.id] == 0
        )
        order = {node.id: i for i, node in enumerate(graph.nodes)}
        return pending, resolved, dependents, unresolved, ready, order

    async def run(self, graph: ExecutionGraph) -> ExecutionGraph:
        """Execute every node, fanning out independent nodes concurrently."""
        self.prepare_execution(graph)
        self.recover_verification(graph)
        active: dict[asyncio.Task[None], Node] = {}
        pending, resolved, dependents, unresolved, ready, order = self._schedule_state(
            graph, active,
        )
        if not pending:
            return graph

        # None intentionally retains the documented unlimited mode.  With a
        # concrete cap, the active task set can never grow beyond that cap.
        concurrency = self._max_concurrency or max(1, len(pending))

        try:
            while ready or active:
                admission_error: Exception | None = None
                while ready and len(active) < concurrency:
                    node = ready.popleft()
                    try:
                        self._reserve_node(node)
                    except Exception as exc:
                        # No provider call has started for this node. Stop
                        # admitting work, settle/cancel what is already in
                        # flight, then surface the admission failure.
                        if isinstance(exc, BudgetValidationError):
                            self.mark_accounting_invalid(node, exc)
                            self.notify_update(node)
                        ready.appendleft(node)
                        admission_error = exc
                        break
                    task = asyncio.create_task(
                        self._execute_node(node, graph),
                        name=f"smythe-node-{node.id}",
                    )
                    active[task] = node

                if admission_error is not None:
                    await self._cancel_and_settle(active)
                    raise admission_error
                if not active:
                    break

                done, _ = await asyncio.wait(
                    active, return_when=asyncio.FIRST_COMPLETED,
                )
                first_error: Exception | None = None
                just_completed: list[Node] = []
                for task in sorted(done, key=lambda item: order[active[item].id]):
                    node = active.pop(task)
                    try:
                        task.result()
                    except asyncio.CancelledError:
                        raise
                    except Exception as exc:
                        if first_error is None:
                            first_error = exc
                        continue

                    pending.pop(node.id, None)
                    resolved.add(node.id)
                    just_completed.append(node)
                    for child in dependents.get(node.id, []):
                        if child.id not in pending:
                            continue
                        unresolved[child.id] -= 1
                        if unresolved[child.id] == 0:
                            ready.append(child)

                if first_error is None and just_completed:
                    revised = False
                    for node in just_completed:
                        revised |= await self._regenerate_and_settle(node, graph, active)
                        if self._supervisor is not None:
                            revised |= await self.maybe_revise(node, graph)
                    if revised:
                        (
                            pending, resolved, dependents, unresolved, ready, order,
                        ) = self._schedule_state(graph, active)

                if first_error is not None:
                    # HALT means no queued sibling may start after the error
                    # is observed. Cancel in-flight siblings and always await
                    # them so no provider task escapes the failed run.
                    await self._cancel_and_settle(active)
                    raise first_error
        except BaseException:
            await self._cancel_and_settle(active)
            raise

        if pending:
            failed = [n for n in graph.nodes if n.status == NodeStatus.FAILED]
            if failed:
                raise RuntimeError(
                    f"Execution halted: {len(pending)} node(s) blocked by "
                    f"{len(failed)} failed upstream node(s)"
                )
            raise RuntimeError("Deadlock: pending nodes exist but none are ready")
        return graph

    def _reserve_node(self, node: Node) -> None:
        """Reserve the best available per-call estimate before admission."""
        self.reserve_node_budget(
            node, default_estimated_tokens=self._estimated_tokens_per_node,
        )

    async def _cancel_and_settle(
        self, active: dict[asyncio.Task[None], Node],
        affected_ids: set[str] | None = None,
    ) -> tuple[list[BaseException], bool]:
        """Cancel and await active node tasks, releasing unused reservations."""
        tasks = [task for task, node in active.items()
                 if affected_ids is None or node.id in affected_ids]
        if not tasks:
            return [], False
        for task in tasks:
            task.cancel()
        async def outcome(task):
            try:
                return await task
            except BaseException as exc:
                # gather() normalizes cancelled tasks to plain CancelledError;
                # retain native accounting evidence carried by its subclass.
                return exc

        settled = asyncio.gather(*(outcome(task) for task in tasks))
        interrupted = False
        while not settled.done():
            try:
                await asyncio.shield(settled)
            except asyncio.CancelledError:
                # Repeated cancellation cannot detach a billed artifact write.
                interrupted = True
        errors = [result for result in settled.result() if isinstance(result, BaseException)]
        for task in tasks:
            node = active.pop(task)
            if node.status in (NodeStatus.PENDING, NodeStatus.RUNNING):
                self.release_node_budget(node)
                node.status = NodeStatus.PENDING
                node.result = None
        return errors, interrupted

    async def _regenerate_and_settle(
        self, node: Node, graph: ExecutionGraph, active: dict[asyncio.Task[None], Node],
    ) -> bool:
        intent = self.prepare_regeneration(node, graph)
        if intent is None:
            return False
        errors, interrupted = await self._cancel_and_settle(
            active, set(intent["affected_generations"]),
        )
        for error in errors:
            if isinstance(error, (
                BudgetValidationError, NodeFinalizationError, SentinelAlert,
                VerificationRecoveryError, ProviderResponseError, WorkflowError,
            )):
                # Retain the intent and all accounting: recovery must not hide
                # an unusable bill or buy a replacement for a failed write.
                raise error
        if interrupted:
            raise asyncio.CancelledError
        self.apply_regeneration(node, graph, intent)
        return True

    async def _execute_node(self, node: Node, graph: ExecutionGraph) -> None:
        """Run a single node through the provider, respecting its failure policy."""
        last_exc: Exception | None = None
        attempts = 1 + max(node.max_retries, 0) if node.failure_policy == FailurePolicy.RETRY else 1

        for attempt in range(attempts):
            self._call_attempts[node.id] = attempt
            delay = self.retry_delay_s(attempt)
            if delay:
                await asyncio.sleep(delay)
            node.status = NodeStatus.RUNNING
            self.begin_verification(node, graph)
            self._tracer.on_node_start(node)

            try:
                # Cost recording happens inside acall_node (per provider call).
                result = await self.acall_node(node, graph)
                # Artifact writes are file I/O — keep them off the event
                # loop so a wide wave's completions don't serialize.
                finalize_task = asyncio.create_task(
                    asyncio.to_thread(self.finalize_node_result, node, result),
                )
                while not finalize_task.done():
                    try:
                        await asyncio.shield(finalize_task)
                    except asyncio.CancelledError:
                        # Once billed, finish persistence even after repeated
                        # cancels. The scheduler awaits us before invalidation.
                        continue
                    except Exception as exc:
                        raise NodeFinalizationError(node.id, exc) from exc
                try:
                    finalize_task.result()
                except Exception as exc:
                    raise NodeFinalizationError(node.id, exc) from exc
                node.status = NodeStatus.COMPLETED
                self._tracer.on_node_end(node)
                self.complete_verification(node)
                self.notify_update(node)
                return
            except VerificationRecoveryError:
                raise
            except (BudgetValidationError, NodeFinalizationError, SentinelAlert,
                    ProviderResponseError, WorkflowError) as exc:
                # A reconciliation alert or post-billing persistence failure
                # is non-retryable here: another provider call would compound
                # the spend rather than repair the local failure. Invalid
                # accounting also retains its reservation until reconciled.
                if isinstance(exc, BudgetValidationError):
                    self.mark_accounting_invalid(node, exc)
                node.status = NodeStatus.FAILED
                node.result = str(exc)
                self._tracer.on_node_error(node, exc)
                self._tracer.on_node_end(node)
                self.notify_update(node)
                raise
            except asyncio.CancelledError:
                self.release_node_budget(node)
                node.status = NodeStatus.PENDING
                node.result = None
                self._tracer.on_node_end(node)
                raise
            except Exception as exc:
                last_exc = exc
                self._tracer.on_node_error(node, exc)
                self._tracer.on_node_end(node)

        self.release_node_budget(node)

        node.result = str(last_exc)

        if node.failure_policy == FailurePolicy.SKIP:
            node.status = NodeStatus.SKIPPED
            self.notify_update(node)
            return

        node.status = NodeStatus.FAILED
        self.notify_update(node)
        raise last_exc  # type: ignore[misc]
