"""Tests for budget tracking and enforcement."""

import pytest

from smythe.budget import (
    BudgetEstimateRequired,
    BudgetReconciliationError,
    BudgetValidationError,
    SentinelAlert,
    Sentinel,
)
from smythe.executor import Executor
from smythe.graph import ExecutionGraph, Node, NodeStatus, Topology
from smythe.provider import CompletionResult, Provider
from smythe.registry import Registry
from smythe.tracer import Tracer


class TokenCountingMockProvider(Provider):
    """Provider that returns configurable token counts."""

    def __init__(self, prompt_tokens: int = 100, completion_tokens: int = 50) -> None:
        self._prompt_tokens = prompt_tokens
        self._completion_tokens = completion_tokens
        self.calls: list[str] = []

    async def complete(self, system: str, prompt: str, model: str) -> CompletionResult:
        node_label = prompt.split("\n")[0]
        self.calls.append(node_label)
        return CompletionResult(
            text=f"result for: {node_label}",
            prompt_tokens=self._prompt_tokens,
            completion_tokens=self._completion_tokens,
        )


def test_budget_tracks_cost():
    tracker = Sentinel(max_budget_usd=10.0, cost_per_token=0.000003)
    r1 = CompletionResult(text="hi", prompt_tokens=100, completion_tokens=50)
    r2 = CompletionResult(text="there", prompt_tokens=200, completion_tokens=100)

    tracker.record("node-1", r1)
    tracker.record("node-2", r2)

    expected = (150 + 300) * 0.000003
    assert abs(tracker.total_cost_usd - expected) < 1e-10
    assert len(tracker.breakdown()) == 2
    assert "node-1" in tracker.breakdown()
    assert "node-2" in tracker.breakdown()


def test_budget_raises_when_exhausted():
    tracker = Sentinel(max_budget_usd=0.0001, cost_per_token=0.000003)
    r = CompletionResult(text="big", prompt_tokens=10000, completion_tokens=10000)
    with pytest.raises(BudgetReconciliationError) as exc_info:
        tracker.record("node-1", r)

    assert exc_info.value.node_id == "node-1"
    assert exc_info.value.spent > 0
    assert exc_info.value.limit == 0.0001


def test_no_budget_means_no_limit():
    tracker = Sentinel(max_budget_usd=None, cost_per_token=0.000003)
    r = CompletionResult(text="huge", prompt_tokens=1_000_000, completion_tokens=1_000_000)

    for i in range(100):
        tracker.record(f"node-{i}", r)
        tracker.check(f"node-{i + 1}")

    assert tracker.total_cost_usd > 0


def test_executor_halts_on_budget():
    """Build a 3-node serial graph; budget runs out after node 2."""
    provider = TokenCountingMockProvider(prompt_tokens=1000, completion_tokens=500)
    cost_per_call = 1500 * 0.000003  # $0.0045 per node
    budget_limit = cost_per_call * 2  # exactly enough for 2 calls; check triggers before node 3

    budget = Sentinel(max_budget_usd=budget_limit, cost_per_token=0.000003)
    tracer = Tracer()
    registry = Registry()

    a = Node(label="Step A", id="a")
    b = Node(label="Step B", id="b", depends_on=["a"])
    c = Node(label="Step C", id="c", depends_on=["b"])
    graph = ExecutionGraph(topology=[Topology.SERIAL], nodes=[a, b, c])

    executor = Executor(provider=provider, registry=registry, tracer=tracer, budget=budget)

    with pytest.raises(SentinelAlert) as exc_info:
        executor.run(graph)

    assert exc_info.value.node_id == "c"
    assert len(provider.calls) == 2
    assert a.status == NodeStatus.COMPLETED
    assert b.status == NodeStatus.COMPLETED
    assert c.status == NodeStatus.PENDING


def test_budget_breakdown_per_node():
    tracker = Sentinel(max_budget_usd=1.0, cost_per_token=0.00001)
    tracker.record("alpha", CompletionResult(text="a", prompt_tokens=100, completion_tokens=50))
    tracker.record("beta", CompletionResult(text="b", prompt_tokens=200, completion_tokens=100))

    breakdown = tracker.breakdown()
    assert breakdown["alpha"] == 150 * 0.00001
    assert breakdown["beta"] == 300 * 0.00001


def test_budget_exhausted_error_message():
    err = SentinelAlert(spent=0.50, limit=0.50, node_id="node-x")
    assert "node-x" in str(err)
    assert "$0.50" in str(err)


def test_budget_reserve_prevents_overspend():
    """3 nodes want to reserve; budget only allows ~2."""
    tracker = Sentinel(max_budget_usd=0.012, cost_per_token=0.000003)
    estimated_cost = 2000 * 0.000003  # $0.006 per node

    tracker.reserve("node-a", estimated_cost)
    tracker.reserve("node-b", estimated_cost)

    with pytest.raises(SentinelAlert) as exc_info:
        tracker.reserve("node-c", estimated_cost)

    assert exc_info.value.node_id == "node-c"


def test_budget_reserve_exact_fit_survives_float_accumulation():
    """A budget sized exactly for N ceiling reservations admits all N.

    Observed live: the 192nd $0.06 reservation of an $11.52 budget was
    rejected with $0.06 nominally remaining, because 191 accumulated float
    additions had drifted past the exact-fit boundary.
    """
    tracker = Sentinel(max_budget_usd=192 * 0.06, cost_per_token=0.000003)
    for index in range(192):
        tracker.reserve(f"glyph-{index:03d}", 0.06)
    assert len(tracker._reservations) == 192

    with pytest.raises(SentinelAlert):
        tracker.reserve("one-more", 0.06)


def test_budget_record_replaces_reservation():
    """Actual cost should replace the estimated reservation."""
    tracker = Sentinel(max_budget_usd=1.0, cost_per_token=0.000003)
    estimated_cost = 2000 * 0.000003  # $0.006

    tracker.reserve("node-a", estimated_cost)
    assert abs(tracker.total_cost_usd - estimated_cost) < 1e-10

    actual_result = CompletionResult(text="x", prompt_tokens=100, completion_tokens=50)
    actual_cost = tracker.record("node-a", actual_result)

    expected_actual = 150 * 0.000003
    assert abs(actual_cost - expected_actual) < 1e-10
    assert abs(tracker.total_cost_usd - expected_actual) < 1e-10


def test_budget_release_on_failure():
    """Releasing a reservation should restore the spent budget."""
    tracker = Sentinel(max_budget_usd=0.01, cost_per_token=0.000003)
    estimated = 2000 * 0.000003

    tracker.reserve("node-a", estimated)
    assert abs(tracker.total_cost_usd - estimated) < 1e-10

    tracker.release("node-a")
    assert abs(tracker.total_cost_usd) < 1e-10

    tracker.reserve("node-b", estimated)
    assert abs(tracker.total_cost_usd - estimated) < 1e-10


def test_budget_release_nonexistent_is_safe():
    """Releasing a node that was never reserved should be a no-op."""
    tracker = Sentinel(max_budget_usd=1.0)
    tracker.release("ghost-node")
    assert tracker.total_cost_usd == 0.0


def test_add_cost_accumulates_per_node():
    from smythe.provider import CompletionResult

    s = Sentinel(max_budget_usd=1.0, cost_per_token=0.000003)
    r1 = CompletionResult(text="a", prompt_tokens=500, completion_tokens=500)
    r2 = CompletionResult(text="b", prompt_tokens=250, completion_tokens=250)

    total1 = s.add_cost("n1", r1)
    total2 = s.add_cost("n1", r2)

    assert total2 > total1
    assert s.breakdown()["n1"] == total2
    assert s.total_cost_usd == total2


def test_add_cost_releases_reservation_once():
    from smythe.provider import CompletionResult

    s = Sentinel(max_budget_usd=1.0, cost_per_token=0.000003)
    s.reserve("n1", 0.01)
    assert s.total_cost_usd == 0.01

    r = CompletionResult(text="a", prompt_tokens=500, completion_tokens=500)
    s.add_cost("n1", r)  # replaces the reservation with actuals
    first = s.total_cost_usd
    assert first == s.breakdown()["n1"]

    s.add_cost("n1", r)  # no reservation left to release; just accumulates
    assert s.total_cost_usd == first * 2


def test_explicit_cost_overrides_token_math():
    """A provider-priced call (cost_usd) wins over the blended token rate."""
    tracker = Sentinel(max_budget_usd=10.0, cost_per_token=0.000003)
    priced = CompletionResult(
        text="img", prompt_tokens=10, completion_tokens=1290, cost_usd=0.039,
    )
    tracker.record("node-1", priced)
    assert abs(tracker.total_cost_usd - 0.039) < 1e-10


def test_explicit_cost_accumulates_via_add_cost():
    tracker = Sentinel(max_budget_usd=10.0, cost_per_token=0.000003)
    priced = CompletionResult(text="img", cost_usd=0.05)
    unpriced = CompletionResult(text="txt", prompt_tokens=100, completion_tokens=0)
    tracker.add_cost("node-1", priced)
    tracker.add_cost("node-1", unpriced)
    expected = 0.05 + 100 * 0.000003
    assert abs(tracker.total_cost_usd - expected) < 1e-10


def test_negative_explicit_cost_is_rejected_without_erasing_valid_cost():
    tracker = Sentinel(max_budget_usd=1.0)
    tracker.record("n1", CompletionResult(text="x", cost_usd=0.5))
    result = CompletionResult(text="x", cost_usd=0.0)
    result.cost_usd = -0.4  # Custom providers may mutate a valid result.
    with pytest.raises(BudgetValidationError, match="cost_usd"):
        tracker.add_cost("n1", result)
    assert tracker.total_cost_usd == pytest.approx(0.5)


def test_reconciliation_overrun_is_recorded_and_halts():
    """An inaccurate ceiling must be visible and stop further execution."""
    tracker = Sentinel(max_budget_usd=1.0)
    tracker.reserve("image", 0.05, hard_ceiling=True)

    with pytest.raises(BudgetReconciliationError) as exc_info:
        tracker.add_cost("image", CompletionResult(text="img", cost_usd=0.06))

    assert exc_info.value.actual_cost == pytest.approx(0.06)
    assert exc_info.value.reserved_cost == pytest.approx(0.05)
    assert tracker.total_cost_usd == pytest.approx(0.06)
    assert tracker.breakdown()["image"] == pytest.approx(0.06)


def test_unknown_cost_consumes_explicit_reservation_conservatively():
    tracker = Sentinel(max_budget_usd=0.10)
    tracker.reserve("image", 0.07)
    result = CompletionResult(text="img", cost_usd=0.0, cost_usd_unknown=True)

    assert tracker.add_cost("image", result) == pytest.approx(0.07)
    assert tracker.total_cost_usd == pytest.approx(0.07)
    assert tracker.cost_is_complete
    assert tracker.cost_contains_estimates


def test_partial_charge_above_hard_ceiling_is_not_hidden():
    tracker = Sentinel(max_budget_usd=1.0)
    tracker.reserve("image", 0.05, hard_ceiling=True)
    result = CompletionResult(
        text="img",
        cost_usd=0.10,
        cost_usd_is_estimate=True,
        cost_usd_unknown=True,
    )

    with pytest.raises(BudgetReconciliationError) as exc_info:
        tracker.add_cost("image", result)

    assert exc_info.value.actual_cost == pytest.approx(0.10)
    assert tracker.total_cost_usd == pytest.approx(0.10)


def test_unreserved_unknown_cost_is_not_fake_text_token_dollars():
    tracker = Sentinel(max_budget_usd=None, cost_per_token=999.0)
    result = CompletionResult(
        text="img",
        prompt_tokens=10,
        completion_tokens=20,
        cost_usd=0.0,
        cost_usd_unknown=True,
    )

    tracker.add_cost("image", result)

    assert tracker.total_cost_usd == 0.0
    assert tracker.breakdown()["image"] == 0.0
    assert not tracker.cost_is_complete
    assert not tracker.cost_contains_estimates

    tracker.add_cost(
        "unknown-without-explicit",
        CompletionResult(
            text="img",
            prompt_tokens=10,
            completion_tokens=20,
            cost_usd_unknown=True,
        ),
    )
    assert tracker.breakdown()["unknown-without-explicit"] == 0.0


def test_partial_output_estimate_is_retained_but_total_is_incomplete():
    tracker = Sentinel(max_budget_usd=None)
    result = CompletionResult(
        text="img",
        cost_usd=0.041,
        cost_usd_is_estimate=True,
        cost_usd_unknown=True,
    )

    tracker.add_cost("image", result)

    assert tracker.total_cost_usd == pytest.approx(0.041)
    assert not tracker.cost_is_complete
    assert tracker.cost_contains_estimates


def test_reservation_rejects_negative_and_duplicate_estimates():
    tracker = Sentinel(max_budget_usd=1.0)
    with pytest.raises(ValueError, match="non-negative"):
        tracker.reserve("negative", -0.01)

    tracker.reserve("duplicate", 0.01)
    with pytest.raises(ValueError, match="already has"):
        tracker.reserve("duplicate", 0.01)


def test_sentinel_rejects_negative_budget_configuration():
    with pytest.raises(ValueError, match="max_budget_usd"):
        Sentinel(max_budget_usd=-0.01)
    with pytest.raises(ValueError, match="cost_per_token"):
        Sentinel(cost_per_token=-0.01)


def test_restore_rejects_negative_checkpoint_cost():
    with pytest.raises(ValueError, match="Checkpoint cost"):
        Sentinel(max_budget_usd=1.0).restore({"tampered": -0.50})


def test_serial_image_call_without_inclusive_ceiling_fails_before_provider():
    class UnpricedImageProvider(Provider):
        def __init__(self):
            self.calls = 0

        def requires_explicit_budget_estimate(self, model: str) -> bool:
            return True

        async def complete(self, system: str, prompt: str, model: str):
            self.calls += 1
            return CompletionResult(text="img", cost_usd=0.05)

    provider = UnpricedImageProvider()
    nodes = [
        Node(id="image", label="generate", metadata={"model": "image-model"}),
        Node(id="later", label="must not start", metadata={"model": "image-model"}),
    ]
    graph = ExecutionGraph(topology=[Topology.FORK_JOIN], nodes=nodes)
    executor = Executor(
        provider=provider,
        registry=Registry(),
        tracer=Tracer(),
        budget=Sentinel(max_budget_usd=1.0),
        artifact_dir=None,
    )

    with pytest.raises(BudgetEstimateRequired):
        executor.run(graph)
    assert provider.calls == 0
