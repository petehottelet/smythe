"""Separate Code Workflow pilot; guarded native API, isolated configuration."""
import argparse
import asyncio
from contextlib import nullcontext
from dataclasses import asdict, is_dataclass
import hashlib
import io
import json
import os
from pathlib import Path
import re
import secrets
import sys
import tempfile
import threading
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from code_guard import Guard, server, save
from benchmarks import fable_runtime as native
from benchmarks.astra_campaign import load_task_pack, check_output
from benchmarks.astra_study import study_task
from smythe.task import task_to_dict
from claude_agent_sdk import query, ClaudeAgentOptions, ResultMessage, AssistantMessage, ToolUseBlock

parser = argparse.ArgumentParser()
parser.add_argument('--mock', action='store_true')
parser.add_argument('--main-task', required=True)
args = parser.parse_args()
root = HERE / ('code-mock-' + secrets.token_hex(4) if args.mock else 'campaign')
parent_stage = root / 'ultracode-main'
stage = parent_stage / 'revised' / args.main_task
prior = 0
lock = nullcontext() if args.mock else native.evidence._campaign_lock(root)
lock.__enter__()
if not args.mock:
    inspected = native.inspect(root / 'pilot')
    if not inspected['complete']:
        raise SystemExit('Complete native pilot before Code timing trials')
    if stage.exists():
        raise SystemExit('Code pilot already has evidence; no automatic retry')
    native.campaign_balance(root)
    allowed = {r['task_id'] for r in json.loads(native.PREPARATION.read_text(encoding='utf-8'))['schedule'] if r['stage'] == 'main'}
    if args.main_task not in allowed:
        raise SystemExit('Main task is outside the frozen ten-task comparison')
    pilot_code = json.loads((root / 'ultracode-pilot/outcome.json').read_text(encoding='utf-8'))
    judgments = json.loads((root / 'judge/pilot-bindings.json').read_text(encoding='utf-8'))
    rating = next(r for r in judgments if r['run_id'] == 'ultracode-pilot')['scores']
    if (not pilot_code['checks']['deterministic_passed'] or pilot_code['workflow_invocations'] < 1
            or rating['material_defects'] or any(r['score'] < 3 for r in rating['criteria'])):
        raise SystemExit('Code pilot quality gate has not passed')
    prior = json.loads((parent_stage / 'spending.json').read_text(encoding='utf-8'))['confirmed_nanousd']
    if prior + 5_000_000_000 > native.ALLOCATIONS['ultracode-main']:
        raise SystemExit('Code main stage cannot reserve another whole workflow')
stage.mkdir(parents=True)
case = next(c for c in load_task_pack().tasks if c.task_id == args.main_task)
prompt = ('Use a Workflow to solve the supplied task. The workflow must perform the analysis '
          'and return the final requested bare JSON. Use no outside sources, files, shell, or web. '
          'Use the exact model identifier claude-fable-5-1 for every agent. '
          'Do not use a display name or shorthand model alias. '
          'Use at most eight agents and no nested subagents. '
          'Return the answer directly; do not write an output file.\n\n'
          + json.dumps(task_to_dict(study_task(case)), ensure_ascii=False))
save(stage / 'prompt.txt', prompt.encode())
real_key = 'mock-no-real-credential'
if not args.mock:
    match = re.search(r'^\s*(?:export\s+)?ANTHROPIC_API_KEY\s*=\s*(.*?)\s*$',
                     (ROOT / '.env').read_text(encoding='utf-8-sig'), re.M)
    if not match:
        raise SystemExit('Missing Anthropic key')
    real_key = match.group(1).strip().strip('\"\'')
token = secrets.token_urlsafe(32)
guard = Guard(stage / 'native', real_key, token)
if args.mock:
    class Response(io.BytesIO):
        status = 200
        headers = {'Content-Type': 'application/json'}
    def upstream(path, body, headers):
        payload = json.loads(body)
        if path.endswith('count_tokens'):
            return Response(b'{"input_tokens":100}')
        raw = {'id': 'msg_mock', 'type': 'message', 'role': 'assistant', 'model': 'claude-fable-5-1',
               'stop_reason': 'end_turn', 'stop_sequence': None,
               'content': [{'type': 'text', 'text': 'Mock transport succeeded.'}],
               'usage': {'input_tokens': 100, 'output_tokens': 20, 'cache_read_input_tokens': 0,
                         'cache_creation_input_tokens': 0, 'service_tier': 'standard'}}
        if not payload.get('stream'):
            return Response(json.dumps(raw).encode())
        events = [{'type': 'message_start', 'message': {**raw, 'content': [], 'stop_reason': None}},
                  {'type': 'content_block_start', 'index': 0, 'content_block': {'type': 'text', 'text': ''}},
                  {'type': 'content_block_delta', 'index': 0,
                   'delta': {'type': 'text_delta', 'text': 'Mock transport succeeded.'}},
                  {'type': 'content_block_stop', 'index': 0},
                  {'type': 'message_delta', 'delta': {'stop_reason': 'end_turn', 'stop_sequence': None},
                   'usage': {'output_tokens': 20}}, {'type': 'message_stop'}]
        response = Response(b''.join(('event: ' + event['type'] + '\ndata: ' + json.dumps(event) + '\n\n').encode()
                                     for event in events))
        response.headers = {'Content-Type': 'text/event-stream'}
        return response
    guard.upstream = upstream

http = server(guard)
thread = threading.Thread(target=http.serve_forever, daemon=True)
thread.start()
work = Path(tempfile.mkdtemp(prefix='smythe-fable-code-'))
config = stage / 'config'
config.mkdir()
# The child gets no real provider credential and no user's Claude settings.
preserve = {key: value for key, value in os.environ.items() if key.upper() in {
    'PATH', 'SYSTEMROOT', 'WINDIR', 'TEMP', 'TMP', 'USERPROFILE', 'APPDATA', 'LOCALAPPDATA',
    'COMSPEC', 'PATHEXT', 'PROGRAMFILES', 'COMMONPROGRAMFILES', 'NUMBER_OF_PROCESSORS'}}
os.environ.clear()
os.environ.update(preserve)
settings = {'ANTHROPIC_API_KEY': token, 'ANTHROPIC_BASE_URL': f'http://127.0.0.1:{http.server_port}',
            'ANTHROPIC_DEFAULT_HAIKU_MODEL': 'claude-fable-5-1',
            'ANTHROPIC_DEFAULT_SONNET_MODEL': 'claude-fable-5-1',
            'ANTHROPIC_DEFAULT_OPUS_MODEL': 'claude-fable-5-1',
            'CLAUDE_CODE_SUBAGENT_MODEL': 'claude-fable-5-1',
            'CLAUDE_CODE_MAX_OUTPUT_TOKENS': '8192',
            'CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH': '1',
            'CLAUDE_CODE_MAX_CONCURRENT_SUBAGENTS': '8',
            'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC': '1',
            'CLAUDE_CONFIG_DIR': str(config)}
options = ClaudeAgentOptions(cwd=str(work), model='claude-fable-5-1', effort='medium',
    tools=['Workflow'], allowed_tools=['Workflow'], setting_sources=[], mcp_servers={},
    permission_mode='default', max_budget_usd=4.0, max_turns=20, env=settings)
frozen = {'mock': args.mock, 'task_id': case.task_id, 'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
          'model': 'claude-fable-5-1', 'effort': 'medium', 'required_tool': 'Workflow',
          'sdk_version': '0.2.152', 'code_version': '2.1.259', 'guard_cap_nanousd': guard.cap,
          'sdk_stop_threshold_usd': 4.0, 'max_output_tokens': 8192, 'max_turns': 20,
          'source_sha256': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                            for path in (Path(__file__), HERE / 'code_guard.py')},
          'native_price_version': native.PRICE_VERSION,
          'scope': 'Code Workflow with pre-dispatch reservations; native cohort remains separate',
          'claimable': False}
save(stage / 'freeze.json', json.dumps(frozen, indent=2).encode())
runtime_archive = stage / 'runtime'
runtime_archive.mkdir()
for path in (Path(__file__), HERE / 'code_guard.py'):
    save(runtime_archive / path.name, path.read_bytes())
spending = stage / 'spending.json'
outer_spending = parent_stage / 'spending.json'
outer_spending.write_text(json.dumps({'status': 'running', 'confirmed_nanousd': prior,
    'reserved_nanousd': guard.cap, 'unknown_nanousd': 0}), encoding='utf-8')
spending.write_text(json.dumps({'status': 'running', 'confirmed_nanousd': 0,
    'reserved_nanousd': guard.cap, 'unknown_nanousd': 0}), encoding='utf-8')

async def run():
    final, workflows, error = None, 0, None
    start = time.perf_counter_ns()
    with open(stage / 'sdk-events.jsonl', 'xb') as stream:
        try:
            async with asyncio.timeout(1800):
                async for event in query(prompt=prompt, options=options):
                    data = asdict(event) if is_dataclass(event) else {'repr': str(event)}
                    stream.write(json.dumps({'type': type(event).__name__, 'data': data}).encode() + b'\n')
                    stream.flush()
                    os.fsync(stream.fileno())
                    if isinstance(event, AssistantMessage):
                        for block in event.content:
                            if isinstance(block, ToolUseBlock) and block.name == 'Workflow':
                                workflows += 1
                                print('Workflow invoked', flush=True)
                    if isinstance(event, ResultMessage):
                        final = event
                        print(json.dumps({'result': event.subtype, 'sdk_cost_usd': event.total_cost_usd}), flush=True)
        except BaseException as caught:
            error = type(caught).__name__
    elapsed = time.perf_counter_ns() - start
    # Do not close the accounting server while an already dispatched response is arriving.
    for _ in range(610):
        if guard.totals()['reserved_nanousd'] == 0:
            break
        await asyncio.sleep(1)
    total = guard.totals()
    known = total['reserved_nanousd'] == total['unknown_nanousd'] == total['unknown_calls'] == 0
    result = {'claimable': False, 'mock': args.mock, 'workflow_invocations': workflows,
              'wall_time_ns': elapsed, 'error': error, 'native_accounting': total,
              'sdk_result': None if final is None else asdict(final)}
    if final is not None and final.result:
        result['checks'] = check_output(case, final.result)
    save(stage / 'outcome.json', json.dumps(result, indent=2).encode())
    spending.write_text(json.dumps({'status': 'settled' if known else 'unknown',
        'confirmed_nanousd': total['confirmed_nanousd'], 'reserved_nanousd': total['reserved_nanousd'],
        'unknown_nanousd': total['unknown_nanousd']}), encoding='utf-8')
    outer_spending.write_text(json.dumps({'status': 'settled' if known else 'unknown',
        'confirmed_nanousd': prior + total['confirmed_nanousd'], 'reserved_nanousd': total['reserved_nanousd'],
        'unknown_nanousd': total['unknown_nanousd']}), encoding='utf-8')
    print(json.dumps({'status': 'finished', 'mock': args.mock, 'workflow_invocations': workflows,
                      'billing_complete': known, **total}), flush=True)
    if args.mock and (final is None or final.result != 'Mock transport succeeded.' or not known or total['calls'] < 1):
        raise RuntimeError('Code SDK mock qualification failed')

try:
    asyncio.run(run())
finally:
    http.shutdown()
    http.server_close()
    thread.join()
    lock.__exit__(None, None, None)
