"""Execute the predeclared ten-task Code comparison, once per task."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from benchmarks import fable_runtime as runtime

root = HERE / 'campaign'
stage = root / 'ultracode-main'
prep = json.loads(runtime.PREPARATION.read_text(encoding='utf-8'))
tasks = []
for row in prep['schedule']:
    if row['stage'] == 'main' and row['repetition'] == 1 and row['task_id'] not in tasks:
        tasks.append(row['task_id'])
assert len(tasks) == 10
sources = {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
           for name in ('code_run_v2.py', 'code_guard.py', 'run_code_main_v2.py')}
plan = {'kind': 'separate-code-workflow-comparison', 'tasks': tasks, 'repetitions': 1,
        'cap_nanousd': runtime.ALLOCATIONS['ultracode-main'], 'per_workflow_nanousd': runtime.CAP,
        'source_sha256': sources, 'pilot_outcome_sha256': hashlib.sha256(
            (root / 'ultracode-pilot/outcome.json').read_bytes()).hexdigest(),
        'judge_bindings_sha256': hashlib.sha256((root / 'judge/pilot-bindings.json').read_bytes()).hexdigest(),
        'diagnostic_prefix_sha256': hashlib.sha256((stage / 'diagnostic-prefix.json').read_bytes()).hexdigest(),
        'native_cohort': 'same task/repetition-one inputs; independent Code runtime'}
with runtime.evidence._campaign_lock(root):
    runtime.campaign_balance(root)
    stage.mkdir(exist_ok=True)
    runtime._write_same(stage / 'schedule-v2.json', plan)
    if not (stage / 'spending.json').exists():
        runtime.evidence._write_new(stage / 'spending.json', {'status': 'settled', 'confirmed_nanousd': 0,
                                                           'reserved_nanousd': 0, 'unknown_nanousd': 0})
    archive = stage / 'runtime-v2'
    archive.mkdir(exist_ok=True)
    for name, digest in sources.items():
        body = (HERE / name).read_bytes()
        assert hashlib.sha256(body).hexdigest() == digest
        target = archive / name
        if target.exists():
            assert target.read_bytes() == body
        else:
            target.write_bytes(body)
for index, identity in enumerate(tasks):
    if sources != {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in sources}:
        raise SystemExit('Code runtime changed after freeze')
    if (stage / 'revised' / identity / 'outcome.json').exists():
        continue
    if (stage / 'revised' / identity).exists():
        raise SystemExit('Interrupted Code task; reconcile locally before continuing')
    print(f'{index + 1}/10 {identity}', flush=True)
    completed = subprocess.run([str(HERE / 'code-env/Scripts/python.exe'), str(HERE / 'code_run_v2.py'),
                                '--main-task', identity], cwd=ROOT)
    if completed.returncode:
        raise SystemExit(completed.returncode)
    runtime.campaign_balance(root)
    outcome = json.loads((stage / 'revised' / identity / 'outcome.json').read_text(encoding='utf-8'))
    print(json.dumps({'task_id': identity, 'workflow_invocations': outcome['workflow_invocations'],
                      'checks': outcome.get('checks'), 'cost_nanousd': outcome['native_accounting']['confirmed_nanousd']}), flush=True)
print('All ten scheduled Code tasks have retained outcomes.', flush=True)
