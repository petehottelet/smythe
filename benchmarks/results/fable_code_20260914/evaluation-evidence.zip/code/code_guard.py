"""Local, token-only Code benchmark gateway with persistent per-request reserves.

The Code child receives a disposable local token. Only this process holds the
provider credential. It forwards to a fixed Anthropic endpoint and saves bodies,
never authorization headers. This is a private qualification implementation.
"""
from dataclasses import dataclass
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import threading
from urllib.request import Request, urlopen
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from smythe.pricing_anthropic import MODEL, messages_quote_nanousd, price_messages_response
from smythe.provider_responses import _json_dump, _json_load


def save(path, body):
    with open(path, 'xb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())


def stream_message(body):
    """Reconstruct the invoice and output from retained Anthropic SSE frames."""
    message, stopped, blocks, partial = None, False, {}, {}
    for packet in body.decode('utf-8').replace('\r\n', '\n').split('\n\n'):
        data = '\n'.join(line[5:].lstrip() for line in packet.splitlines() if line.startswith('data:'))
        if not data:
            continue
        event = _json_load(data)
        kind = event.get('type')
        if kind == 'message_start':
            if message is not None:
                raise ValueError('Repeated stream start')
            message = event['message']
        elif kind == 'content_block_start':
            index = event['index']
            if index in blocks:
                raise ValueError('Repeated stream block')
            blocks[index] = event['content_block']
        elif kind == 'content_block_delta':
            block, delta = blocks[event['index']], event['delta']
            kind = delta['type']
            for key, delta_kind in [('text', 'text_delta'), ('thinking', 'thinking_delta'), ('signature', 'signature_delta')]:
                if kind == delta_kind:
                    block[key] = block.get(key, '') + delta[key]
            if kind == 'input_json_delta':
                partial[event['index']] = partial.get(event['index'], '') + delta['partial_json']
        elif kind == 'message_delta':
            if message is None:
                raise ValueError('Usage before message start')
            message.update(event['delta'])
            message['usage'].update(event.get('usage', {}))
        elif kind == 'message_stop':
            stopped = True
        elif kind == 'error':
            raise ValueError('Provider stream error')
    if message is None or not stopped:
        raise ValueError('Incomplete provider stream')
    for index, data in partial.items():
        blocks[index]['input'] = _json_load(data)
    message['content'] = [blocks[index] for index in sorted(blocks)]
    return message


def invoice(raw):
    # Declared client-side tools have no separate provider fee; server tools are
    # prohibited in requests and usage. Keep their raw output in evidence.
    for block in raw.get('content', []):
        if block.get('type') not in {'text', 'thinking', 'redacted_thinking', 'tool_use'}:
            raise ValueError('Unpriced Code output content')
    priced = price_messages_response({**raw, 'content': []})
    if priced.cost_nanousd is None:
        raise ValueError(priced.accounting_error)
    return priced


@dataclass
class Guard:
    directory: Path
    api_key: str
    local_token: str
    cap: int = 5_000_000_000

    def __post_init__(self):
        self.directory.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        with self.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS calls (id INTEGER PRIMARY KEY, state TEXT NOT NULL, reserve INTEGER NOT NULL, cost INTEGER, sha TEXT NOT NULL)')

    @contextmanager
    def db(self):
        conn = sqlite3.connect(self.directory / 'requests.sqlite3', timeout=60)
        try:
            conn.execute('PRAGMA synchronous=FULL')
            with conn:
                yield conn
        finally:
            conn.close()

    def totals(self):
        with self.db() as db:
            rows = db.execute('SELECT state,reserve,cost FROM calls').fetchall()
        return {'confirmed_nanousd': sum(r[2] or 0 for r in rows),
                'reserved_nanousd': sum(r[1] for r in rows if r[0] == 'dispatched'),
                'unknown_nanousd': sum(r[1] for r in rows if r[0] == 'unknown'),
                'unknown_calls': sum(r[0] == 'unknown' for r in rows), 'calls': len(rows)}

    def reserve(self, request, ceiling):
        with self.lock, self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            rows = db.execute('SELECT state,reserve,cost FROM calls').fetchall()
            if any(row[0] == 'unknown' for row in rows):
                raise ValueError('Unknown earlier billing closes dispatch')
            used = sum(row[2] if row[0] == 'settled' else row[1] for row in rows)
            if used + ceiling > self.cap:
                raise ValueError('Whole-request reserve exceeds Code workflow allowance')
            row = db.execute('INSERT INTO calls(state,reserve,sha) VALUES(?,?,?)',
                             ('dispatched', ceiling, hashlib.sha256(request).hexdigest()))
            identity = row.lastrowid
            save(self.directory / f'{identity:04d}.request.json', request)
            return identity

    def settle(self, identity, cost):
        with self.lock, self.db() as db:
            db.execute('UPDATE calls SET state=?,cost=? WHERE id=?',
                       ('settled' if cost is not None else 'unknown', cost, identity))

    def upstream(self, path, body, headers):
        keep = {k: v for k, v in headers.items() if k.lower() in {'anthropic-version', 'anthropic-beta'}}
        keep.update({'x-api-key': self.api_key, 'content-type': 'application/json'})
        return urlopen(Request('https://api.anthropic.com' + path, data=body, headers=keep), timeout=600)


def server(guard):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def error(self, message):
            body = _json_dump({'type': 'error', 'error': {'type': 'permission_error', 'message': message}}).encode()
            self.send_response(403)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            identity, raw = None, bytearray()
            try:
                auth = self.headers.get('x-api-key') or self.headers.get('Authorization', '').removeprefix('Bearer ')
                if auth != guard.local_token or self.path.split('?')[0] not in {'/v1/messages', '/v1/messages/count_tokens'}:
                    return self.error('Local benchmark endpoint only')
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 2_000_000:
                    return self.error('Request size outside benchmark scope')
                original = self.rfile.read(length)
                payload = _json_load(original)
                if payload.get('model') != MODEL:
                    return self.error('Benchmark pins every call to Fable 5.1')
                for tool in payload.get('tools', []):
                    if tool.get('type', 'custom') != 'custom':
                        return self.error('Provider-hosted tools are outside this benchmark')
                count_path = '/v1/messages/count_tokens'
                if self.path.split('?')[0] == count_path:
                    with guard.upstream(count_path, original, dict(self.headers)) as response:
                        body, status = response.read(), response.status
                    self.send_response(status)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Content-Length', str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                cap = payload.get('max_tokens')
                if type(cap) is not int or not 1 <= cap <= 8192 or payload.get('speed') not in (None, 'standard'):
                    return self.error('Output cap or speed is outside the Code protocol')
                payload['service_tier'] = 'standard_only'
                encoded = _json_dump(payload).encode()
                count = {k: v for k, v in payload.items()
                         if k in {'model', 'messages', 'system', 'tools', 'tool_choice', 'thinking', 'output_config'}}
                with guard.upstream(count_path, _json_dump(count).encode(), dict(self.headers)) as response:
                    count_body = response.read()
                ceiling = messages_quote_nanousd(_json_load(count_body)['input_tokens'], cap)
                identity = guard.reserve(encoded, ceiling)
                save(guard.directory / f'{identity:04d}.count.json', count_body)
                with guard.upstream('/v1/messages', encoded, dict(self.headers)) as response:
                    self.send_response(response.status)
                    self.send_header('Content-Type', response.headers.get('Content-Type', 'application/json'))
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    while chunk := response.read1(65536):
                        raw.extend(chunk)
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()
                        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                            # Finish reading and settling the invoice after a child disconnects.
                            pass
                save(guard.directory / f'{identity:04d}.response.raw', bytes(raw))
                message = stream_message(bytes(raw)) if payload.get('stream') else _json_load(bytes(raw))
                receipt = invoice(message)
                save(guard.directory / f'{identity:04d}.receipt.json', _json_dump(receipt.safe_summary()).encode())
                save(guard.directory / f'{identity:04d}.message.json', _json_dump(message).encode())
                guard.settle(identity, receipt.cost_nanousd)
            except Exception as exc:
                if identity is not None:
                    if isinstance(exc, HTTPError):
                        raw.extend(exc.read())
                    path = guard.directory / f'{identity:04d}.response.raw'
                    if not path.exists():
                        save(path, bytes(raw))
                    guard.settle(identity, None)
                else:
                    try:
                        self.error(type(exc).__name__ + ': request not dispatched')
                    except (BrokenPipeError, ConnectionResetError):
                        pass
            finally:
                self.close_connection = True

    return ThreadingHTTPServer(('127.0.0.1', 0), Handler)
