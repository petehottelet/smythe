"""Offline reconciliation of retained Code requests, stream bytes and invoices."""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in (HERE, *HERE.parents, Path.cwd())
            if (p / 'smythe').is_dir() and (p / 'benchmarks').is_dir())
sys.path.insert(0, str(ROOT))
from code_guard import stream_message, invoice
from smythe.pricing_anthropic import MODEL, messages_quote_nanousd
from benchmarks.astra_campaign import load_task_pack, check_output


def read(path):
    return json.loads(path.read_bytes())


def audit(folder):
    folder = Path(folder)
    frozen, outcome = read(folder / 'freeze.json'), read(folder / 'outcome.json')
    assert frozen['mock'] is outcome['mock'] is False
    assert frozen['model'] == MODEL and frozen['effort'] == 'medium'
    assert hashlib.sha256((folder / 'prompt.txt').read_bytes()).hexdigest() == frozen['prompt_sha256']
    for name, expected in frozen['source_sha256'].items():
        assert hashlib.sha256((folder / 'runtime' / name).read_bytes()).hexdigest() == expected
    with sqlite3.connect((folder / 'native/requests.sqlite3').resolve().as_uri() + '?mode=ro', uri=True) as db:
        rows = db.execute('SELECT id,state,reserve,cost,sha FROM calls ORDER BY id').fetchall()
    assert [r[0] for r in rows] == list(range(1, len(rows) + 1))
    total, categories, efforts, stops = 0, {}, {}, {}
    for identity, state, reserve, cost, digest in rows:
        prefix = folder / 'native' / f'{identity:04d}'
        raw_request = Path(str(prefix) + '.request.json').read_bytes()
        assert hashlib.sha256(raw_request).hexdigest() == digest
        request = json.loads(raw_request)
        assert request['model'] == MODEL and request['service_tier'] == 'standard_only'
        assert 0 < request['max_tokens'] <= frozen['max_output_tokens']
        assert all(t.get('type', 'custom') == 'custom' for t in request.get('tools', []))
        count = read(Path(str(prefix) + '.count.json'))['input_tokens']
        assert reserve == messages_quote_nanousd(count, request['max_tokens'])
        raw = Path(str(prefix) + '.response.raw').read_bytes()
        message = stream_message(raw) if request.get('stream') else json.loads(raw)
        assert message == read(Path(str(prefix) + '.message.json'))
        receipt = invoice(message)
        assert receipt.safe_summary() == read(Path(str(prefix) + '.receipt.json'))
        assert state == 'settled' and receipt.cost_nanousd == cost and 0 <= cost <= reserve
        total += cost
        for key, value in receipt.safe_summary()['categories'].items():
            categories[key] = categories.get(key, 0) + value['cost_nanousd']
        effort = request.get('output_config', {}).get('effort', 'unspecified')
        efforts[effort] = efforts.get(effort, 0) + 1
        stops[message['stop_reason']] = stops.get(message['stop_reason'], 0) + 1
    assert total <= frozen['guard_cap_nanousd']
    assert outcome['native_accounting'] == {'confirmed_nanousd': total, 'reserved_nanousd': 0,
        'unknown_nanousd': 0, 'unknown_calls': 0, 'calls': len(rows)}
    events = [json.loads(line) for line in (folder / 'sdk-events.jsonl').read_bytes().splitlines()]
    results = [r['data'] for r in events if r['type'] == 'ResultMessage']
    assert results and outcome['sdk_result'] == results[-1]
    workflows = sum(b.get('name') == 'Workflow' for r in events if r['type'] == 'AssistantMessage'
                    for b in r['data'].get('content', []) if isinstance(b, dict))
    assert workflows == outcome['workflow_invocations']
    case = next(c for c in load_task_pack().tasks if c.task_id == frozen['task_id'])
    assert outcome['checks'] == check_output(case, results[-1]['result'])
    assert abs(results[-1]['total_cost_usd'] * 1_000_000_000 - total) < 1
    return {'task_id': frozen['task_id'], 'cost_nanousd': total, 'api_calls': len(rows),
            'workflow_invocations': workflows, 'wall_time_ns': outcome['wall_time_ns'],
            'error': outcome['error'], 'contract_passed': outcome['checks']['deterministic_passed'],
            'protocol_passed': workflows > 0 and outcome['error'] is None,
            'cost_categories_nanousd': categories, 'request_efforts': efforts,
            'stop_reasons': stops, 'output_sha256': hashlib.sha256(results[-1]['result'].encode()).hexdigest(),
            'outcome_sha256': hashlib.sha256((folder / 'outcome.json').read_bytes()).hexdigest()}


if __name__ == '__main__':
    print(json.dumps(audit(Path(sys.argv[1])), indent=2))
