"""YAML loader — build ExecutionGraphs from declarative DAG files."""

from __future__ import annotations

from pathlib import Path

import yaml

from smythe.agent import Agent, AgentProfile
from smythe.graph import ExecutionGraph, FailurePolicy, Node, Topology
from smythe.registry import Registry


def load_graph(path: str | Path) -> tuple[ExecutionGraph, Registry]:
    """Load an ExecutionGraph and accompanying Registry from a YAML file."""
    text = Path(path).read_text(encoding="utf-8")
    return load_graph_from_string(text)


def load_graph_from_string(yaml_str: str) -> tuple[ExecutionGraph, Registry]:
    """Parse a YAML string into an ExecutionGraph and Registry."""
    data = yaml.safe_load(yaml_str)
    if not isinstance(data, dict):
        raise ValueError("YAML root must be a mapping")
    return build_graph_from_dict(data)


def build_graph_from_dict(data: dict) -> tuple[ExecutionGraph, Registry]:
    """Build an ExecutionGraph and Registry from a parsed dict.

    Shared by the YAML loader and the LLM planner.  The dict must have
    a ``topology`` key (string or list of strings) and a ``nodes`` list.
    Each node entry may include an ``agent`` sub-dict with name, persona,
    and capabilities.
    """
    topology = _parse_topology(data.get("topology", ["serial"]))

    registry = Registry()
    nodes: list[Node] = []

    nodes_raw = data.get("nodes", [])
    if not isinstance(nodes_raw, list):
        raise ValueError(
            f"'nodes' must be a list, got {type(nodes_raw).__name__}"
        )

    for i, entry in enumerate(nodes_raw):
        if not isinstance(entry, dict):
            raise ValueError(
                f"Node at index {i} must be a mapping, got {type(entry).__name__}"
            )
        node_id = entry.get("id")
        if not node_id:
            raise ValueError("Every node must have an 'id' field")

        label = entry.get("label", node_id)
        depends_on = entry.get("depends_on", [])
        metadata = entry.get("metadata", {})
        required_capabilities = entry.get("required_capabilities", [])

        if not isinstance(depends_on, list):
            raise ValueError(f"'depends_on' on node {node_id!r} must be a list")
        if not isinstance(metadata, dict):
            raise ValueError(f"'metadata' on node {node_id!r} must be a mapping")
        if not isinstance(required_capabilities, list):
            raise ValueError(f"'required_capabilities' on node {node_id!r} must be a list")

        fp_raw = entry.get("failure_policy", "halt")
        try:
            failure_policy = FailurePolicy(fp_raw.lower())
        except ValueError:
            valid = [fp.value for fp in FailurePolicy]
            raise ValueError(
                f"Unknown failure_policy {fp_raw!r} on node {node_id!r}. "
                f"Valid values: {valid}"
            ) from None

        max_retries = entry.get("max_retries", 1)

        timeout_s = entry.get("timeout_s")
        if timeout_s is not None:
            if isinstance(timeout_s, bool) or not isinstance(timeout_s, (int, float)):
                raise ValueError(
                    f"'timeout_s' on node {node_id!r} must be a number, "
                    f"got {type(timeout_s).__name__}"
                )
            if timeout_s <= 0:
                raise ValueError(
                    f"'timeout_s' on node {node_id!r} must be positive, got {timeout_s}"
                )
            timeout_s = float(timeout_s)

        max_tool_iterations = entry.get("max_tool_iterations")
        if max_tool_iterations is not None:
            if isinstance(max_tool_iterations, bool) or not isinstance(max_tool_iterations, int):
                raise ValueError(
                    f"'max_tool_iterations' on node {node_id!r} must be an integer, "
                    f"got {type(max_tool_iterations).__name__}"
                )
            if max_tool_iterations < 1:
                raise ValueError(
                    f"'max_tool_iterations' on node {node_id!r} must be >= 1, "
                    f"got {max_tool_iterations}"
                )

        attach_dep_artifacts = entry.get("attach_dep_artifacts", False)
        if not isinstance(attach_dep_artifacts, bool):
            raise ValueError(
                f"'attach_dep_artifacts' on node {node_id!r} must be a boolean, "
                f"got {type(attach_dep_artifacts).__name__}"
            )

        verifies = entry.get("verifies")
        if verifies is not None and not isinstance(verifies, str):
            raise ValueError(
                f"'verifies' on node {node_id!r} must be a node id string, "
                f"got {type(verifies).__name__}"
            )

        max_regenerations = entry.get("max_regenerations", 0)
        if isinstance(max_regenerations, bool) or not isinstance(max_regenerations, int):
            raise ValueError(
                f"'max_regenerations' on node {node_id!r} must be an integer, "
                f"got {type(max_regenerations).__name__}"
            )
        if max_regenerations < 0:
            raise ValueError(
                f"'max_regenerations' on node {node_id!r} must be >= 0, "
                f"got {max_regenerations}"
            )

        node = Node(
            id=node_id,
            label=label,
            depends_on=depends_on,
            metadata=metadata,
            failure_policy=failure_policy,
            max_retries=max_retries,
            required_capabilities=required_capabilities,
            timeout_s=timeout_s,
            max_tool_iterations=max_tool_iterations,
            attach_dep_artifacts=attach_dep_artifacts,
            verifies=verifies,
            max_regenerations=max_regenerations,
        )

        agent_data = entry.get("agent")
        if agent_data:
            mcp_raw = agent_data.get("mcp_servers", [])
            if not isinstance(mcp_raw, list):
                raise ValueError(
                    f"'mcp_servers' on node {node_id!r} agent must be a list"
                )
            mcp_servers = []
            for server_entry in mcp_raw:
                if not isinstance(server_entry, dict):
                    raise ValueError(
                        f"Each mcp_servers entry on node {node_id!r} must be a mapping"
                    )
                from smythe.mcp import MCPConfigError, MCPServerSpec
                try:
                    mcp_servers.append(MCPServerSpec.from_dict(server_entry))
                except (MCPConfigError, KeyError) as exc:
                    raise ValueError(
                        f"Invalid mcp_servers entry on node {node_id!r}: {exc}"
                    ) from exc

            profile = AgentProfile(
                name=agent_data.get("name", node_id),
                persona=agent_data.get("persona", ""),
                capabilities=agent_data.get("capabilities", []),
                mcp_servers=mcp_servers,
            )
            agent = Agent(profile=profile)
            registry.register(agent)
            node.agent_id = agent.id
            node.metadata["agent_name"] = agent.name

        nodes.append(node)

    known_ids = {node.id for node in nodes}
    for node in nodes:
        if node.verifies is not None and node.verifies not in known_ids:
            raise ValueError(
                f"Node {node.id!r} 'verifies' names unknown node "
                f"{node.verifies!r}"
            )
        if node.verifies == node.id:
            raise ValueError(f"Node {node.id!r} cannot 'verifies' itself")

    graph = ExecutionGraph(topology=topology, nodes=nodes)
    graph.validate()
    return graph, registry


def _parse_topology(raw: str | list[str]) -> list[Topology]:
    """Convert a topology value (string or list of strings) to Topology enums."""
    if isinstance(raw, str):
        raw = [raw]

    result: list[Topology] = []
    for item in raw:
        normalized = item.strip().lower()
        try:
            result.append(Topology(normalized))
        except ValueError:
            valid = [t.value for t in Topology]
            raise ValueError(
                f"Unknown topology {item!r}. Valid values: {valid}"
            ) from None
    return result
